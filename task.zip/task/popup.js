$(document).ready(function(){



    var dNow = new Date();
    var localTime= (dNow.getHours());
    
    if(localTime<12)
    $('#currentDate').text('Hai Good Moring!')
    else  if(localTime>=12 && localTime<=15)
    $('#currentDate').text("Hai good afternoon!")
    else if(localTime>=16 && localTime<=20)
    $('#currentDate').text('Hai Good Evening!!')
    else
      $('#currentDate').text('Hai Good night!!')


});
